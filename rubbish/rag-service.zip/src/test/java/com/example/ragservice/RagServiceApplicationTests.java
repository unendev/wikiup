package com.example.ragservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RagServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
